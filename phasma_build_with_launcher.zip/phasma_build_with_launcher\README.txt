﻿Phasma Build Template with Desktop Launcher
============================================

This folder sets up Phasma on a new Raspberry Pi.

Files:
- phasma_gui.py               : main Python program
- words.txt                   : full word list
- phonemes_arpabet.txt        : ARPAbet phoneme list
- icons/phasma.png            : app icon (replace with your real PNG)
- phasma.desktop              : desktop launcher (copy to ~/Desktop)

Setup steps (on the Pi):
1. Copy this folder to ~/phasma/
2. Install deps:
   sudo apt update
   sudo apt install espeak-ng python3-tk python3-pil python3-pil.imagetk
3. Enable bit-banged I2C bus 3 (GPIO5=SDA, GPIO6=SCL):
   echo 'dtoverlay=i2c-gpio,bus=3,i2c_gpio_sda=5,i2c_gpio_scl=6' | sudo tee -a /boot/config.txt
   sudo reboot
4. Put launcher on Desktop:
   cp ~/phasma/phasma.desktop ~/Desktop/
   chmod +x ~/Desktop/phasma.desktop
5. Run manually:
   DISPLAY=:0 python3 ~/phasma/phasma_gui.py
